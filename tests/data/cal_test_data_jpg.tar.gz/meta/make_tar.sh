#!/bin/bash

set -eou pipefail

echo "run this from the calibration_test_data folder"
echo "e.g.: ./meta/make_tar.sh"

target=cal_test_data_jpg.tar.gz

tar --exclude=$target -czf $target *

echo "Done. Wrote to $target"

