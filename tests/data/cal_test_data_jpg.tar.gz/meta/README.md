Data acquired June 2024 from Olveckzy Lab Room #3
Balser Ace2 Cameras
Acquired as TIFF's then compressed to JPG's (using ImageMagick --quality=50)
Calibration target is HDPE/aluminum from vendor Calib.io
Calib tarball initially created 2024-07-17


